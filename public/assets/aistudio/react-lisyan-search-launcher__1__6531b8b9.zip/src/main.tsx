import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./fonts/led-dot-matrix.css";
import "./index.css";
import App from "./App";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>
);
