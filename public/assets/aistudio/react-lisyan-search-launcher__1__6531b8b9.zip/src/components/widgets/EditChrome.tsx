import { Check, ChevronLeft, Grid3x3, Move, PanelRightClose, PanelRightOpen, Plus } from "lucide-react";
import { useEffect, useState } from "react";
import { FaceGallery, LayoutControls, WidgetEditor, WidgetList } from "./editor";
import { BUTTON_PRIMARY } from "../ui";
import { useI18n } from "../../lib/i18n";
import { MAX_WIDGETS, type ClockWidget, type HomeLayout } from "../../lib/settings";
import type { WidgetActions } from "../../lib/widgets";
import { cn } from "../../utils/cn";

type Props = {
  widgets: ClockWidget[];
  layout: HomeLayout;
  selectedId: string | null;
  dragging: boolean;
  actions: WidgetActions;
  onSelect: (id: string | null) => void;
  onExit: () => void;
};

/** Toolbar and side panel shown while the home screen is being edited. */
export default function EditChrome({ widgets, layout, selectedId, dragging, actions, onSelect, onExit }: Props) {
  const { t } = useI18n();
  const [panel, setPanel] = useState<"home" | "add">("home");
  const [open, setOpen] = useState(true);
  const selected = widgets.find((widget) => widget.id === selectedId) ?? null;
  const full = widgets.length >= MAX_WIDGETS;
  const title = selected ? t(`wf.f.${selected.face}`) : panel === "add" ? t("home.chooseFace") : t("sec.home");

  useEffect(() => {
    if (!selectedId) return;
    setPanel("home");
    setOpen(true);
  }, [selectedId]);

  const openGallery = () => {
    onSelect(null);
    setPanel("add");
    setOpen(true);
  };

  return (
    <>
      <div className={cn("pointer-events-none fixed inset-x-0 top-4 z-[60] flex justify-center px-3 transition-opacity duration-200", dragging && "opacity-0")}>
        <div
          role="toolbar"
          aria-label={t("home.editing")}
          className="pointer-events-auto flex max-w-full items-center gap-1 overflow-x-auto rounded-full bg-[var(--surface)] p-1.5 shadow-[0_10px_30px_rgb(0_0_0/0.22)] ring-1 ring-[var(--line)]"
        >
          <button
            type="button"
            disabled={full}
            onClick={openGallery}
            className="flex h-10 shrink-0 items-center gap-2 rounded-full bg-[var(--surface-container-high)] px-4 text-sm font-medium transition-all duration-300 hover:rounded-[14px] hover:bg-[var(--surface-container-highest)] disabled:opacity-40"
          >
            <Plus size={17} aria-hidden="true" />
            <span className="hidden sm:inline">{t("home.add")}</span>
          </button>
          <div role="radiogroup" aria-label={t("home.layout")} className="flex shrink-0 rounded-full bg-[var(--surface-container-high)] p-1">
            {(["free", "grid"] as const).map((mode) => {
              const Icon = mode === "free" ? Move : Grid3x3;
              const on = layout.mode === mode;
              return (
                <button
                  key={mode}
                  type="button"
                  role="radio"
                  aria-checked={on}
                  onClick={() => actions.layout({ mode })}
                  title={t(`home.mode.${mode}`)}
                  className={cn(
                    "flex h-8 items-center gap-1.5 rounded-full px-3 text-sm transition-all duration-300",
                    on ? "rounded-[11px] bg-[var(--primary)] font-medium text-[var(--on-primary)]" : "hover:bg-[var(--surface-container-highest)]",
                  )}
                >
                  <Icon size={15} aria-hidden="true" />
                  <span className="hidden sm:inline">{t(`home.mode.${mode}`)}</span>
                </button>
              );
            })}
          </div>
          <button
            type="button"
            onClick={() => setOpen((value) => !value)}
            aria-pressed={open}
            title={open ? t("home.hidePanel") : t("home.showPanel")}
            aria-label={open ? t("home.hidePanel") : t("home.showPanel")}
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full transition hover:bg-[var(--surface-container-high)]"
          >
            {open ? <PanelRightClose size={18} className="rtl:-scale-x-100" aria-hidden="true" /> : <PanelRightOpen size={18} className="rtl:-scale-x-100" aria-hidden="true" />}
          </button>
          <button type="button" onClick={onExit} className={cn(BUTTON_PRIMARY, "h-10")}>
            <Check size={17} aria-hidden="true" />
            {t("home.done")}
          </button>
        </div>
      </div>

      {open && (
        <aside
          aria-label={title}
          className={cn(
            "fixed z-[60] flex flex-col overflow-hidden rounded-[28px] bg-[var(--sidebar)] shadow-[0_24px_60px_rgb(0_0_0/0.3)] ring-1 ring-[var(--line)] transition-opacity duration-200",
            "inset-x-2 bottom-2 max-h-[52vh] md:inset-x-auto md:bottom-4 md:end-4 md:top-20 md:max-h-none md:w-[380px]",
            dragging && "pointer-events-none opacity-0",
          )}
        >
          <header className="flex items-center gap-1 border-b border-[var(--line)] px-2 py-2">
            {(selected || panel === "add") && (
              <button
                type="button"
                onClick={() => {
                  onSelect(null);
                  setPanel("home");
                }}
                title={t("wg.back")}
                aria-label={t("wg.back")}
                className="flex h-10 w-10 items-center justify-center rounded-full transition hover:bg-[var(--surface-container-high)]"
              >
                <ChevronLeft size={20} className="rtl:rotate-180" aria-hidden="true" />
              </button>
            )}
            <h2 className="type-display min-w-0 flex-1 truncate px-2 py-1.5 text-lg font-semibold">{title}</h2>
          </header>
          <div className="min-h-0 flex-1 overflow-y-auto p-3">
            {selected ? (
              <WidgetEditor
                key={selected.id}
                widget={selected}
                onChange={(patch) => actions.change(selected.id, patch)}
                onDuplicate={() => onSelect(actions.duplicate(selected.id))}
                onRemove={() => {
                  actions.remove(selected.id);
                  onSelect(null);
                }}
                canDuplicate={!full}
              />
            ) : panel === "add" ? (
              <FaceGallery
                onPick={(face) => {
                  const id = actions.add(face);
                  setPanel("home");
                  onSelect(id);
                }}
              />
            ) : (
              <div className="space-y-4">
                <LayoutControls layout={layout} onChange={actions.layout} />
                <WidgetList
                  widgets={widgets}
                  selectedId={selectedId}
                  onSelect={onSelect}
                  onDuplicate={(id) => onSelect(actions.duplicate(id))}
                  onRemove={actions.remove}
                  canDuplicate={!full}
                />
                <button type="button" disabled={full} onClick={openGallery} className={cn(BUTTON_PRIMARY, "w-full justify-center")}>
                  <Plus size={17} aria-hidden="true" />
                  {t("home.add")}
                </button>
                <p className="px-1 text-xs leading-5 text-[var(--muted)]">{full ? t("home.limit") : t("home.keys")}</p>
              </div>
            )}
          </div>
        </aside>
      )}
    </>
  );
}
