import { useSyncExternalStore } from "react";
import { FACE_COMPONENTS } from "./faces";
import { getClockTime, useNow } from "../../lib/clock";
import { FACE_META } from "../../lib/faces";
import { useI18n } from "../../lib/i18n";
import type { ClockWidget } from "../../lib/settings";
import { cn } from "../../utils/cn";

const motionQuery = typeof window === "undefined" ? null : window.matchMedia("(prefers-reduced-motion: reduce)");
const subscribeMotion = (listener: () => void) => {
  motionQuery?.addEventListener("change", listener);
  return () => motionQuery?.removeEventListener("change", listener);
};
const prefersReducedMotion = () => motionQuery?.matches ?? false;

export const useReducedMotion = () => useSyncExternalStore(subscribeMotion, prefersReducedMotion, () => false);

type Props = {
  widget: ClockWidget;
  width: number;
  faceHeight: number;
  captionHeight?: number;
  caption?: string;
  /** Soft shadow that keeps the clock readable over a wallpaper. */
  halo?: boolean;
};

/** Renders one clock face with the widget's colour role, options and time zone. */
export default function Clock({ widget, width, faceHeight, captionHeight = 0, caption = "", halo = false }: Props) {
  const { lang, t } = useI18n();
  const now = useNow();
  const reducedMotion = useReducedMotion();
  const meta = FACE_META[widget.face];
  const Face = FACE_COMPONENTS[widget.face];
  const time = getClockTime(now, lang, widget.timeZone, widget.hourCycle);
  const seconds = meta.seconds && widget.seconds !== "off";
  // A sweeping hand is a never-ending CSS animation — fall back to ticking for reduced motion.
  const sweep = seconds && meta.sweep && widget.seconds === "sweep" && !reducedMotion;
  const date = meta.date && widget.date;
  const label = `${t(`wf.f.${widget.face}`)}: ${time.hour}:${time.minute}${time.h12 ? ` ${time.dayPeriod}` : ""}${caption ? `, ${caption}` : ""}`;

  return (
    <div
      className={cn("wf", halo && "wf--halo")}
      data-role={widget.color}
      role="img"
      aria-label={label}
      style={{ width, height: faceHeight + captionHeight, opacity: widget.opacity / 100 }}
    >
      <div className="wf-face" style={{ height: faceHeight }} aria-hidden="true">
        <Face time={time} widget={widget} seconds={seconds} sweep={sweep} date={date} />
      </div>
      {captionHeight > 0 && (
        <div className="wf-caption" style={{ height: captionHeight, lineHeight: `${captionHeight}px`, fontSize: Math.round(captionHeight / 1.7) }} aria-hidden="true">
          {caption}
        </div>
      )}
    </div>
  );
}
