import { ChevronDown, Copy, Trash2 } from "lucide-react";
import { useMemo, useState } from "react";
import Clock from "./Clock";
import { BUTTON, CARD, FieldRow, INPUT, Segmented, SliderRow, ToggleRow } from "../ui";
import { cityName, timeZoneOptions } from "../../lib/clock";
import { FACE_META } from "../../lib/faces";
import { useI18n } from "../../lib/i18n";
import {
  CLOCK_FACES,
  DEFAULT_WIDGET,
  HOME_LAYOUT_SCHEMA,
  HOUR_CYCLES,
  WIDGET_COLORS,
  limits,
  type ClockFaceId,
  type ClockWidget,
  type HomeLayout,
  type SecondsMode,
} from "../../lib/settings";
import { SIZE_MAX, SIZE_MIN, captionText, faceFlags } from "../../lib/widgets";
import { cn } from "../../utils/cn";

function fit(ratio: number, maxWidth: number, maxHeight: number) {
  return ratio >= maxWidth / maxHeight
    ? { width: maxWidth, height: Math.round(maxWidth / ratio) }
    : { width: Math.round(maxHeight * ratio), height: maxHeight };
}

/** A live clock scaled to fit a box (galleries, lists). */
export function FaceThumb({ widget, maxWidth, maxHeight }: { widget: ClockWidget; maxWidth: number; maxHeight: number }) {
  const { width, height } = fit(FACE_META[widget.face].ratio(faceFlags(widget)), maxWidth, maxHeight);
  return <Clock widget={widget} width={width} faceHeight={height} />;
}

/** All 25 faces, live, grouped into analogue and digital. */
export function FaceGallery({ value, base, onPick }: { value?: ClockFaceId; base?: Partial<ClockWidget>; onPick: (face: ClockFaceId) => void }) {
  const { t } = useI18n();
  const groups = [
    ["analog", t("wg.analog")],
    ["digital", t("wg.digital")],
  ] as const;
  return (
    <div className="space-y-5">
      {groups.map(([kind, title]) => (
        <section key={kind}>
          <h3 className="mb-2 px-1 text-xs font-semibold uppercase tracking-wider text-[var(--muted)]">{title}</h3>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
            {CLOCK_FACES.filter((face) => FACE_META[face].kind === kind).map((face) => {
              const preview: ClockWidget = { ...DEFAULT_WIDGET, ...FACE_META[face].defaults, ...base, face, id: `preview-${face}`, label: "", opacity: 100 };
              const selected = value === face;
              return (
                <button
                  key={face}
                  type="button"
                  onClick={() => onPick(face)}
                  aria-pressed={selected}
                  className={cn(
                    "flex min-w-0 flex-col items-center gap-2 rounded-[20px] p-3 transition-all duration-300",
                    selected
                      ? "rounded-[14px] bg-[var(--secondary-container)] text-[var(--on-secondary-container)]"
                      : "bg-[var(--surface)] hover:bg-[var(--surface-container-high)]",
                  )}
                >
                  <span className="pointer-events-none flex h-[76px] items-center justify-center" aria-hidden="true">
                    <FaceThumb widget={preview} maxWidth={112} maxHeight={76} />
                  </span>
                  <span className="w-full truncate text-center text-xs font-medium">{t(`wf.f.${face}`)}</span>
                </button>
              );
            })}
          </div>
        </section>
      ))}
    </div>
  );
}

type EditorProps = {
  widget: ClockWidget;
  onChange: (patch: Partial<ClockWidget>) => void;
  onDuplicate: () => void;
  onRemove: () => void;
  canDuplicate: boolean;
};

export function WidgetEditor({ widget, onChange, onDuplicate, onRemove, canDuplicate }: EditorProps) {
  const { t } = useI18n();
  const [picking, setPicking] = useState(false);
  const zones = useMemo(() => timeZoneOptions(), []);
  const meta = FACE_META[widget.face];
  const card = cn(CARD, "divide-y divide-[var(--line)]");
  const secondsOptions: { value: SecondsMode; label: string }[] = [
    { value: "off", label: t("common.none") },
    { value: "tick", label: t("wg.s.tick") },
    ...(meta.sweep ? [{ value: "sweep" as const, label: t("wg.s.sweep") }] : []),
  ];

  return (
    <div className="space-y-4">
      <div className={CARD}>
        <div className="flex items-center gap-4 p-4">
          <span className="flex h-16 w-24 shrink-0 items-center justify-center" aria-hidden="true">
            <FaceThumb widget={widget} maxWidth={96} maxHeight={64} />
          </span>
          <div className="min-w-0 flex-1">
            <div className="text-xs text-[var(--muted)]">{t("wg.face")}</div>
            <div className="truncate font-semibold">{t(`wf.f.${widget.face}`)}</div>
          </div>
          <button type="button" onClick={() => setPicking((open) => !open)} aria-expanded={picking} className={BUTTON}>
            {t("wg.change")}
            <ChevronDown size={16} className={cn("transition-transform duration-300", picking && "rotate-180")} aria-hidden="true" />
          </button>
        </div>
        {picking && (
          <div className="border-t border-[var(--line)] bg-[var(--sidebar)] p-3">
            <FaceGallery
              value={widget.face}
              base={{ color: widget.color, hourCycle: widget.hourCycle, timeZone: widget.timeZone }}
              onPick={(face) => {
                onChange({ face });
                setPicking(false);
              }}
            />
          </div>
        )}
      </div>

      <div className={card}>
        <SliderRow label={t("wg.size")} value={widget.size} min={SIZE_MIN} max={SIZE_MAX} step={4} unit=" px" onChange={(size) => onChange({ size })} />
        <FieldRow label={t("wg.color")}>
          <Segmented label={t("wg.color")} value={widget.color} onChange={(color) => onChange({ color })} options={WIDGET_COLORS.map((value) => ({ value, label: t(`wg.c.${value}`) }))} />
        </FieldRow>
        <SliderRow label={t("wg.opacity")} value={widget.opacity} min={20} max={100} unit="%" onChange={(opacity) => onChange({ opacity })} />
      </div>

      <div className={card}>
        <FieldRow label={t("wg.seconds")} hint={meta.seconds ? undefined : t("wg.unavailable")}>
          <Segmented
            label={t("wg.seconds")}
            value={!meta.sweep && widget.seconds === "sweep" ? "tick" : widget.seconds}
            onChange={(seconds) => onChange({ seconds })}
            options={secondsOptions}
            disabled={!meta.seconds}
          />
        </FieldRow>
        <ToggleRow
          title={t("wg.date")}
          description={meta.date ? undefined : t("wg.unavailable")}
          checked={meta.date && widget.date}
          onChange={(date) => onChange({ date })}
          disabled={!meta.date}
        />
        <FieldRow label={t("wg.format")} hint={meta.format ? undefined : t("wg.unavailable")}>
          <Segmented
            label={t("wg.format")}
            value={widget.hourCycle}
            onChange={(hourCycle) => onChange({ hourCycle })}
            options={HOUR_CYCLES.map((value) => ({ value, label: t(`wg.f.${value}`) }))}
            disabled={!meta.format}
          />
        </FieldRow>
      </div>

      <div className={card}>
        <FieldRow label={t("wg.tz")}>
          <select value={widget.timeZone} onChange={(event) => onChange({ timeZone: event.target.value })} aria-label={t("wg.tz")} className={cn(INPUT, "h-12 cursor-pointer")}>
            <option value="local">{t("wg.tz.local")}</option>
            {zones.map((zone) => (
              <option key={zone.id} value={zone.id}>
                {zone.label}
              </option>
            ))}
          </select>
        </FieldRow>
        <FieldRow label={t("wg.label")} hint={t("wg.labelHint")}>
          <input
            value={widget.label}
            maxLength={40}
            onChange={(event) => onChange({ label: event.target.value })}
            placeholder={widget.timeZone !== "local" ? cityName(widget.timeZone) : t("wg.label")}
            aria-label={t("wg.label")}
            className={cn(INPUT, "h-12")}
          />
        </FieldRow>
      </div>

      <div className="flex flex-wrap gap-2">
        <button type="button" onClick={onDuplicate} disabled={!canDuplicate} className={BUTTON}>
          <Copy size={16} aria-hidden="true" />
          {t("wg.duplicate")}
        </button>
        <button type="button" onClick={onRemove} className={BUTTON}>
          <Trash2 size={16} aria-hidden="true" />
          {t("wg.remove")}
        </button>
      </div>
    </div>
  );
}

export function LayoutControls({ layout, onChange }: { layout: HomeLayout; onChange: (patch: Partial<HomeLayout>) => void }) {
  const { t } = useI18n();
  return (
    <div className={cn(CARD, "divide-y divide-[var(--line)]")}>
      <FieldRow label={t("home.layout")} hint={layout.mode === "grid" ? t("home.mode.gridDesc") : t("home.mode.freeDesc")}>
        <Segmented
          label={t("home.layout")}
          value={layout.mode}
          onChange={(mode) => onChange({ mode })}
          options={[
            { value: "free", label: t("home.mode.free") },
            { value: "grid", label: t("home.mode.grid") },
          ]}
        />
      </FieldRow>
      {layout.mode === "grid" ? (
        <>
          <SliderRow label={t("home.cell")} value={layout.cell} {...limits(HOME_LAYOUT_SCHEMA.cell)} unit=" px" onChange={(cell) => onChange({ cell })} />
          <FieldRow label={t("home.showGrid")}>
            <Segmented
              label={t("home.showGrid")}
              value={layout.showGrid}
              onChange={(showGrid) => onChange({ showGrid })}
              options={(["editing", "always", "never"] as const).map((value) => ({ value, label: t(`home.grid.${value}`) }))}
            />
          </FieldRow>
        </>
      ) : (
        <ToggleRow title={t("home.guides")} description={t("home.guidesDesc")} checked={layout.guides} onChange={(guides) => onChange({ guides })} />
      )}
    </div>
  );
}

type ListProps = {
  widgets: ClockWidget[];
  selectedId: string | null;
  onSelect: (id: string | null) => void;
  onDuplicate: (id: string) => void;
  onRemove: (id: string) => void;
  canDuplicate: boolean;
};

export function WidgetList({ widgets, selectedId, onSelect, onDuplicate, onRemove, canDuplicate }: ListProps) {
  const { t } = useI18n();
  const iconButton = "flex h-9 w-9 shrink-0 items-center justify-center rounded-full transition hover:bg-[var(--surface-container-highest)] disabled:opacity-40";
  return (
    <div className={cn(CARD, "divide-y divide-[var(--line)]")}>
      {widgets.map((widget) => {
        const selected = widget.id === selectedId;
        const name = t(`wf.f.${widget.face}`);
        return (
          <div
            key={widget.id}
            className={cn(
              "flex items-center gap-2 px-3 py-2 transition",
              selected ? "bg-[var(--secondary-container)] text-[var(--on-secondary-container)]" : "hover:bg-[var(--surface-container-high)]",
            )}
          >
            <button type="button" onClick={() => onSelect(selected ? null : widget.id)} aria-pressed={selected} className="flex min-w-0 flex-1 items-center gap-3 text-start">
              <span className="pointer-events-none flex h-12 w-16 shrink-0 items-center justify-center" aria-hidden="true">
                <FaceThumb widget={widget} maxWidth={64} maxHeight={44} />
              </span>
              <span className="min-w-0">
                <span className="block truncate text-sm font-medium">{name}</span>
                <span className="block truncate text-xs opacity-70">{captionText(widget) || t("wg.tz.local")}</span>
              </span>
            </button>
            <button type="button" onClick={() => onDuplicate(widget.id)} disabled={!canDuplicate} title={t("wg.duplicate")} aria-label={`${t("wg.duplicate")}: ${name}`} className={iconButton}>
              <Copy size={16} aria-hidden="true" />
            </button>
            <button type="button" onClick={() => onRemove(widget.id)} title={t("wg.remove")} aria-label={`${t("wg.remove")}: ${name}`} className={iconButton}>
              <Trash2 size={16} aria-hidden="true" />
            </button>
          </div>
        );
      })}
      {!widgets.length && <p className="px-5 py-5 text-sm leading-6 text-[var(--muted)]">{t("home.empty")}</p>}
    </div>
  );
}
