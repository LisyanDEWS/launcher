import { LANGUAGES, type LanguageCode } from "../i18n/languages";

export type ThemeMode = "system" | "light" | "dark" | "wallpaper";
export type LogoMode = "google" | "none" | "text";
export type FontTheme = "m3" | "matrix";
export type LogoFont = "theme" | "sans" | "matrix";
export type WallpaperSource = "none" | "file" | "url";
export type ColorSource = "mono" | "wallpaper" | "preset" | "custom";
export type SchemeVariant = "tonal" | "expressive" | "vibrant" | "fidelity";
export type WallpaperTone = "unknown" | "dark" | "light";
export type SettingsSection =
  | "search"
  | "searchbox"
  | "animation"
  | "home"
  | "appearance"
  | "themes"
  | "wallpaper"
  | "fonts"
  | "language"
  | "bookmarks"
  | "about";
export type Bookmark = { id: string; title: string; url: string };

export const PRESET_IDS = ["ocean", "forest", "sunset", "rose", "violet", "sand", "mint", "crimson"] as const;
export type PresetId = (typeof PRESET_IDS)[number];
export const SCHEME_VARIANTS = ["tonal", "expressive", "vibrant", "fidelity"] as const;

/* ---------- search bar style ---------- */

export const SEARCH_PRESET_IDS = ["expressive", "soft", "outlined", "minimal", "glass", "brutal", "spotlight", "terminal"] as const;
export type SearchPresetId = (typeof SEARCH_PRESET_IDS)[number];
export const SB_FILLS = ["filled", "outlined", "glass", "underline", "transparent"] as const;
export const SB_BORDER_COLORS = ["outline", "primary", "fg"] as const;
export const SB_SHADOWS = ["none", "soft", "medium", "strong", "glow", "hard"] as const;
export const SB_RINGS = ["none", "ring", "glow"] as const;
export const SB_ALIGNS = ["start", "center"] as const;
export const SB_ICONS = ["search", "sparkles", "globe", "chevron", "none"] as const;
export const SB_BUTTONS = ["filled", "tonal", "icon", "none"] as const;

export type SearchStyle = {
  preset: SearchPresetId | "custom";
  width: number;
  height: number;
  radius: number;
  focusRadius: number;
  focusScale: number;
  fill: (typeof SB_FILLS)[number];
  opacity: number;
  blur: number;
  borderWidth: number;
  borderColor: (typeof SB_BORDER_COLORS)[number];
  shadow: (typeof SB_SHADOWS)[number];
  focusRing: (typeof SB_RINGS)[number];
  fontSize: number;
  fontWeight: number;
  align: (typeof SB_ALIGNS)[number];
  icon: (typeof SB_ICONS)[number];
  button: (typeof SB_BUTTONS)[number];
  offsetTop: number;
  placeholder: string;
};

/* ---------- text animation ---------- */

export const ANIM_PRESET_IDS = ["subtle", "expressive", "bouncy", "cinematic", "decode", "off"] as const;
export type AnimPresetId = (typeof ANIM_PRESET_IDS)[number];
export const ENTER_EFFECTS = ["none", "fade", "rise", "drop", "pop", "blur", "flip", "wave", "scramble", "glow"] as const;
export const EXIT_EFFECTS = ["none", "fade", "fall", "rise", "shrink", "blur", "fly", "dissolve"] as const;
export const EASINGS = ["emphasized", "spring", "bouncy", "smooth", "linear"] as const;
export const CARETS = ["native", "bar", "block", "underline"] as const;
export const BLINKS = ["blink", "fade", "solid"] as const;
export type Easing = (typeof EASINGS)[number];

export type TextAnim = {
  preset: AnimPresetId | "custom";
  enabled: boolean;
  enter: (typeof ENTER_EFFECTS)[number];
  exit: (typeof EXIT_EFFECTS)[number];
  enterDuration: number;
  exitDuration: number;
  stagger: number;
  intensity: number;
  easing: Easing;
  highlight: boolean;
  caret: (typeof CARETS)[number];
  caretSmooth: boolean;
  caretBlink: (typeof BLINKS)[number];
  typewriter: boolean;
  typewriterSpeed: number;
};

/* ---------- home screen widgets ---------- */

export const CLOCK_FACES = [
  "classic",
  "cookie",
  "sunny",
  "clover",
  "flower",
  "burst",
  "squircle",
  "numerals",
  "chrono",
  "minimal",
  "orbit",
  "pie",
  "wavy",
  "stacked",
  "bubbles",
  "shapes",
  "wide",
  "thin",
  "flip",
  "segment",
  "matrix",
  "binary",
  "calendar",
  "glance",
  "progress",
] as const;
export type ClockFaceId = (typeof CLOCK_FACES)[number];
export const WIDGET_COLORS = ["primary", "secondary", "tertiary", "neutral"] as const;
export const SECOND_MODES = ["off", "tick", "sweep"] as const;
export const HOUR_CYCLES = ["auto", "h23", "h12"] as const;
export type SecondsMode = (typeof SECOND_MODES)[number];
export type HourCycle = (typeof HOUR_CYCLES)[number];

export type ClockWidget = {
  id: string;
  type: "clock";
  face: ClockFaceId;
  /** Position as a fraction (0–1) of the free space left of / above the widget — survives window resizes. */
  x: number;
  y: number;
  /** Visual size in px: the square root of the face area, so switching faces keeps the visual weight. */
  size: number;
  color: (typeof WIDGET_COLORS)[number];
  seconds: SecondsMode;
  date: boolean;
  hourCycle: HourCycle;
  /** "local" or an IANA time zone name. */
  timeZone: string;
  label: string;
  opacity: number;
};

export type HomeLayout = {
  mode: "free" | "grid";
  /** Grid step in px. */
  cell: number;
  showGrid: "editing" | "always" | "never";
  /** Magnetic guides in free mode. */
  guides: boolean;
};

export const MAX_WIDGETS = 24;

export const DEFAULT_WIDGET: ClockWidget = {
  id: "",
  type: "clock",
  face: "classic",
  x: 0.04,
  y: 0.08,
  size: 200,
  color: "primary",
  seconds: "off",
  date: false,
  hourCycle: "auto",
  timeZone: "local",
  label: "",
  opacity: 100,
};

export const DEFAULT_HOME_LAYOUT: HomeLayout = { mode: "free", cell: 32, showGrid: "editing", guides: true };

/* ---------- all settings ---------- */

export type Settings = {
  language: "auto" | LanguageCode;
  theme: ThemeMode;
  logo: LogoMode;
  logoText: string;
  logoFont: LogoFont;
  fontTheme: FontTheme;
  searchSuggestions: boolean;
  colorSource: ColorSource;
  presetId: PresetId;
  customColor: string;
  schemeVariant: SchemeVariant;
  /** Material contrast level: 0, 0.5 or 1. */
  contrast: number;
  /** Seed colours extracted from the wallpaper (derived, cached for instant start-up). */
  wallpaperColors: string[];
  wallpaperColorIndex: number;
  wallpaperTone: WallpaperTone;
  /** Where the wallpaper comes from; the file itself lives in IndexedDB. */
  wallpaperSource: WallpaperSource;
  wallpaperUrl: string;
  wallpaperDim: number;
  wallpaperBlur: number;
  wallpaperGrayscale: boolean;
  searchStyle: SearchStyle;
  textAnim: TextAnim;
  widgets: ClockWidget[];
  homeLayout: HomeLayout;
};

export const BOOKMARKS_KEY = "lisyan_bookmarks";
export const SETTINGS_KEY = "lisyan_settings";
export const HISTORY_KEY = "lisyan_search_history";
export const GOOGLE_LOGO = "https://cdn.freebiesupply.com/images/large/2x/google-logo-black-transparent.png";

export const DEFAULT_SEARCH_STYLE: SearchStyle = {
  preset: "expressive",
  width: 672,
  height: 64,
  radius: 32,
  focusRadius: 28,
  focusScale: 100,
  fill: "filled",
  opacity: 100,
  blur: 16,
  borderWidth: 0,
  borderColor: "outline",
  shadow: "none",
  focusRing: "none",
  fontSize: 18,
  fontWeight: 400,
  align: "start",
  icon: "search",
  button: "filled",
  offsetTop: 16,
  placeholder: "",
};

const SEARCH_PRESETS: Record<SearchPresetId, Partial<SearchStyle>> = {
  expressive: {},
  soft: { height: 60, radius: 22, focusRadius: 22, shadow: "medium", button: "tonal" },
  outlined: { fill: "outlined", opacity: 0, borderWidth: 2, radius: 16, focusRadius: 16, focusRing: "ring", button: "tonal" },
  minimal: { fill: "underline", borderWidth: 2, borderColor: "fg", radius: 0, focusRadius: 0, height: 56, fontSize: 20, button: "icon" },
  glass: { fill: "glass", opacity: 55, blur: 24, radius: 32, focusRadius: 24, borderWidth: 1, shadow: "soft" },
  brutal: { radius: 0, focusRadius: 0, borderWidth: 3, borderColor: "fg", shadow: "hard", fontWeight: 700 },
  spotlight: { width: 760, height: 76, radius: 38, focusRadius: 38, fontSize: 24, align: "center", icon: "none", button: "none", focusRing: "glow", shadow: "strong", focusScale: 102 },
  terminal: { fill: "outlined", opacity: 0, borderWidth: 1, borderColor: "primary", radius: 8, focusRadius: 8, icon: "chevron", button: "none", fontWeight: 500, focusRing: "glow" },
};

export function applySearchPreset(current: SearchStyle, id: SearchPresetId): SearchStyle {
  // Presets describe the look; the user's own text and position are kept.
  return { ...DEFAULT_SEARCH_STYLE, ...SEARCH_PRESETS[id], preset: id, placeholder: current.placeholder, offsetTop: current.offsetTop };
}

export const DEFAULT_TEXT_ANIM: TextAnim = {
  preset: "expressive",
  enabled: true,
  enter: "rise",
  exit: "fall",
  enterDuration: 320,
  exitDuration: 220,
  stagger: 18,
  intensity: 55,
  easing: "spring",
  highlight: false,
  caret: "bar",
  caretSmooth: true,
  caretBlink: "fade",
  typewriter: true,
  typewriterSpeed: 70,
};

const ANIM_PRESETS: Record<AnimPresetId, Partial<TextAnim>> = {
  subtle: { enabled: true, enter: "fade", exit: "fade", enterDuration: 180, exitDuration: 140, stagger: 10, intensity: 30, easing: "smooth", highlight: false },
  expressive: { enabled: true, enter: "rise", exit: "fall", enterDuration: 320, exitDuration: 220, stagger: 18, intensity: 55, easing: "spring", highlight: false },
  bouncy: { enabled: true, enter: "wave", exit: "shrink", enterDuration: 440, exitDuration: 200, stagger: 28, intensity: 70, easing: "bouncy", highlight: true },
  cinematic: { enabled: true, enter: "blur", exit: "dissolve", enterDuration: 520, exitDuration: 380, stagger: 30, intensity: 65, easing: "emphasized", highlight: false },
  decode: { enabled: true, enter: "scramble", exit: "blur", enterDuration: 380, exitDuration: 180, stagger: 22, intensity: 50, easing: "linear", highlight: true },
  off: { enabled: false },
};

export function applyAnimPreset(current: TextAnim, id: AnimPresetId): TextAnim {
  // Presets change the motion; cursor and placeholder preferences are kept.
  return { ...current, ...ANIM_PRESETS[id], preset: id };
}

type FlatSettings = Omit<Settings, "searchStyle" | "textAnim" | "widgets" | "homeLayout">;

const DEFAULT_FLAT: FlatSettings = {
  language: "auto",
  theme: "system",
  logo: "google",
  logoText: "LisYan",
  logoFont: "theme",
  fontTheme: "m3",
  searchSuggestions: true,
  colorSource: "mono",
  presetId: "ocean",
  customColor: "#6750a4",
  schemeVariant: "tonal",
  contrast: 0,
  wallpaperColors: [],
  wallpaperColorIndex: 0,
  wallpaperTone: "unknown",
  wallpaperSource: "none",
  wallpaperUrl: "",
  wallpaperDim: 35,
  wallpaperBlur: 0,
  wallpaperGrayscale: false,
};

export const DEFAULT_SETTINGS: Settings = {
  ...DEFAULT_FLAT,
  searchStyle: DEFAULT_SEARCH_STYLE,
  textAnim: DEFAULT_TEXT_ANIM,
  widgets: [],
  homeLayout: DEFAULT_HOME_LAYOUT,
};

/* ---------- schema: validation of stored data + slider ranges ---------- */

export type Field =
  | { kind: "enum"; values: readonly string[] }
  | { kind: "number"; min: number; max: number; step: number }
  | { kind: "boolean" }
  | { kind: "string"; max: number }
  | { kind: "color" }
  | { kind: "colors" };
type Schema<T> = { [K in keyof T]-?: Field };

const num = (min: number, max: number, step = 1): Field => ({ kind: "number", min, max, step });
const oneOf = (values: readonly string[]): Field => ({ kind: "enum", values });
const BOOL: Field = { kind: "boolean" };
const str = (max: number): Field => ({ kind: "string", max });
const HEX = /^#[0-9a-f]{6}$/i;

const FLAT_SCHEMA: Schema<FlatSettings> = {
  language: oneOf(["auto", ...LANGUAGES.map((language) => language.code)]),
  theme: oneOf(["system", "light", "dark", "wallpaper"]),
  logo: oneOf(["google", "none", "text"]),
  logoText: str(40),
  logoFont: oneOf(["theme", "sans", "matrix"]),
  fontTheme: oneOf(["m3", "matrix"]),
  searchSuggestions: BOOL,
  colorSource: oneOf(["mono", "wallpaper", "preset", "custom"]),
  presetId: oneOf(PRESET_IDS),
  customColor: { kind: "color" },
  schemeVariant: oneOf(SCHEME_VARIANTS),
  contrast: num(0, 1, 0.5),
  wallpaperColors: { kind: "colors" },
  wallpaperColorIndex: num(0, 5),
  wallpaperTone: oneOf(["unknown", "dark", "light"]),
  wallpaperSource: oneOf(["none", "file", "url"]),
  wallpaperUrl: str(4096),
  wallpaperDim: num(0, 80),
  wallpaperBlur: num(0, 24),
  wallpaperGrayscale: BOOL,
};

export const SEARCH_STYLE_SCHEMA: Schema<SearchStyle> = {
  preset: oneOf([...SEARCH_PRESET_IDS, "custom"]),
  width: num(420, 960, 8),
  height: num(44, 88, 2),
  radius: num(0, 44),
  focusRadius: num(0, 44),
  focusScale: num(100, 106),
  fill: oneOf(SB_FILLS),
  opacity: num(0, 100),
  blur: num(0, 40),
  borderWidth: num(0, 4),
  borderColor: oneOf(SB_BORDER_COLORS),
  shadow: oneOf(SB_SHADOWS),
  focusRing: oneOf(SB_RINGS),
  fontSize: num(14, 28),
  fontWeight: num(300, 800, 100),
  align: oneOf(SB_ALIGNS),
  icon: oneOf(SB_ICONS),
  button: oneOf(SB_BUTTONS),
  offsetTop: num(6, 40),
  placeholder: str(80),
};

export const TEXT_ANIM_SCHEMA: Schema<TextAnim> = {
  preset: oneOf([...ANIM_PRESET_IDS, "custom"]),
  enabled: BOOL,
  enter: oneOf(ENTER_EFFECTS),
  exit: oneOf(EXIT_EFFECTS),
  enterDuration: num(60, 1000, 10),
  exitDuration: num(60, 1000, 10),
  stagger: num(0, 80),
  intensity: num(0, 100),
  easing: oneOf(EASINGS),
  highlight: BOOL,
  caret: oneOf(CARETS),
  caretSmooth: BOOL,
  caretBlink: oneOf(BLINKS),
  typewriter: BOOL,
  typewriterSpeed: num(20, 200, 5),
};

export const WIDGET_SCHEMA: Schema<ClockWidget> = {
  id: str(64),
  type: oneOf(["clock"]),
  face: oneOf(CLOCK_FACES),
  x: num(0, 1, 0.0001),
  y: num(0, 1, 0.0001),
  size: num(80, 480),
  color: oneOf(WIDGET_COLORS),
  seconds: oneOf(SECOND_MODES),
  date: BOOL,
  hourCycle: oneOf(HOUR_CYCLES),
  timeZone: str(64),
  label: str(40),
  opacity: num(20, 100),
};

export const HOME_LAYOUT_SCHEMA: Schema<HomeLayout> = {
  mode: oneOf(["free", "grid"]),
  cell: num(8, 96, 4),
  showGrid: oneOf(["editing", "always", "never"]),
  guides: BOOL,
};

function sanitize<T extends object>(raw: unknown, schema: Schema<T>, defaults: T): T {
  const source = raw && typeof raw === "object" ? (raw as Record<string, unknown>) : {};
  const out = { ...defaults } as Record<string, unknown>;
  for (const key of Object.keys(schema) as (keyof T & string)[]) {
    const field = schema[key];
    const value = source[key];
    switch (field.kind) {
      case "enum":
        if (typeof value === "string" && field.values.includes(value)) out[key] = value;
        break;
      case "number":
        if (typeof value === "number" && Number.isFinite(value)) {
          const stepped = Math.round((value - field.min) / field.step) * field.step + field.min;
          out[key] = Math.min(field.max, Math.max(field.min, Number(stepped.toFixed(4))));
        }
        break;
      case "boolean":
        if (typeof value === "boolean") out[key] = value;
        break;
      case "string":
        if (typeof value === "string") out[key] = value.slice(0, field.max);
        break;
      case "color":
        if (typeof value === "string" && HEX.test(value)) out[key] = value.toLowerCase();
        break;
      case "colors":
        if (Array.isArray(value)) out[key] = value.filter((c): c is string => typeof c === "string" && HEX.test(c)).slice(0, 6);
        break;
    }
  }
  return out as T;
}

/** Slider range of a numeric schema field. */
export function limits(field: Field) {
  return field.kind === "number" ? { min: field.min, max: field.max, step: field.step } : { min: 0, max: 100, step: 1 };
}

function sanitizeWidgets(raw: unknown): ClockWidget[] {
  if (!Array.isArray(raw)) return [];
  const seen = new Set<string>();
  return raw
    .filter((item) => item && typeof item === "object")
    .slice(0, MAX_WIDGETS)
    .map((item) => {
      const widget = sanitize(item, WIDGET_SCHEMA, DEFAULT_WIDGET);
      let id = widget.id.trim();
      if (!id || seen.has(id)) id = Math.random().toString(36).slice(2, 12);
      seen.add(id);
      return { ...widget, id };
    });
}

export function readSettings(): Settings {
  let raw: Record<string, unknown> = {};
  try {
    const parsed: unknown = JSON.parse(localStorage.getItem(SETTINGS_KEY) || "{}");
    if (parsed && typeof parsed === "object") raw = parsed as Record<string, unknown>;
  } catch {
    // Corrupted storage — fall back to defaults.
  }
  return {
    ...sanitize(raw, FLAT_SCHEMA, DEFAULT_FLAT),
    searchStyle: sanitize(raw.searchStyle, SEARCH_STYLE_SCHEMA, DEFAULT_SEARCH_STYLE),
    textAnim: sanitize(raw.textAnim, TEXT_ANIM_SCHEMA, DEFAULT_TEXT_ANIM),
    widgets: sanitizeWidgets(raw.widgets),
    homeLayout: sanitize(raw.homeLayout, HOME_LAYOUT_SCHEMA, DEFAULT_HOME_LAYOUT),
  };
}

export function readBookmarks(): Bookmark[] {
  try {
    const value: unknown = JSON.parse(localStorage.getItem(BOOKMARKS_KEY) || "[]");
    if (!Array.isArray(value)) return [];
    return value.filter(
      (item): item is Bookmark =>
        Boolean(item) && typeof item.id === "string" && typeof item.title === "string" && typeof item.url === "string",
    );
  } catch {
    return [];
  }
}

export function readHistory(): string[] {
  try {
    const value: unknown = JSON.parse(localStorage.getItem(HISTORY_KEY) || "[]");
    return Array.isArray(value) ? value.filter((item): item is string => typeof item === "string") : [];
  } catch {
    return [];
  }
}

export function persist(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // Storage can be unavailable (private mode, quota); the in-memory state still works.
  }
}

export const normalizeUrl = (value: string) => (/^https?:\/\//i.test(value) ? value : `https://${value}`);

export function getHost(value: string) {
  try {
    return new URL(value).hostname.replace(/^www\./, "");
  } catch {
    return value;
  }
}
