import { useEffect, useMemo, useState } from "react";
import type { Dispatch, SetStateAction } from "react";
import { cityName } from "./clock";
import { FACE_META } from "./faces";
import {
  DEFAULT_WIDGET,
  MAX_WIDGETS,
  type ClockFaceId,
  type ClockWidget,
  type HomeLayout,
  type SearchStyle,
  type Settings,
} from "./settings";

export type Viewport = { w: number; h: number };
export type Rect = { left: number; top: number; width: number; height: number };

export const SIZE_MIN = 80;
export const SIZE_MAX = 480;
const EDGE = 24;

export const readViewport = (): Viewport => ({
  w: document.documentElement.clientWidth || window.innerWidth,
  h: document.documentElement.clientHeight || window.innerHeight,
});

export function useViewport(): Viewport {
  const [viewport, setViewport] = useState(readViewport);
  useEffect(() => {
    const update = () => setViewport(readViewport());
    window.addEventListener("resize", update);
    return () => window.removeEventListener("resize", update);
  }, []);
  return viewport;
}

export function uid(): string {
  try {
    return crypto.randomUUID();
  } catch {
    return Math.random().toString(36).slice(2) + Date.now().toString(36);
  }
}

/** What the face actually shows for these options. */
export function faceFlags(widget: ClockWidget) {
  const meta = FACE_META[widget.face];
  return { seconds: meta.seconds && widget.seconds !== "off", date: meta.date && widget.date };
}

/** Caption under the face: the user's text, or the city of a foreign time zone. */
export const captionText = (widget: ClockWidget) => widget.label.trim() || (widget.timeZone !== "local" ? cityName(widget.timeZone) : "");

/** Pixel size of a widget. `size` is √(face area), so every face keeps a similar visual weight. */
export function widgetSize(widget: ClockWidget) {
  const k = Math.sqrt(FACE_META[widget.face].ratio(faceFlags(widget)));
  const width = Math.round(widget.size * k);
  const faceHeight = Math.round(widget.size / k);
  const caption = captionText(widget) ? Math.round(Math.max(13, Math.min(20, widget.size * 0.075)) * 1.7) : 0;
  return { width, faceHeight, caption, height: faceHeight + caption };
}

/** Snaps to the grid without leaving [0, max]. */
export function snapWithin(value: number, step: number, max: number) {
  const snapped = Math.round(value / step) * step;
  if (snapped > max) return Math.max(0, Math.floor(max / step) * step);
  return Math.max(0, snapped);
}

export function widgetRect(widget: ClockWidget, viewport: Viewport, layout: HomeLayout): Rect {
  const { width, height } = widgetSize(widget);
  const spanX = Math.max(0, viewport.w - width);
  const spanY = Math.max(0, viewport.h - height);
  let left = widget.x * spanX;
  let top = widget.y * spanY;
  if (layout.mode === "grid") {
    left = snapWithin(left, layout.cell, spanX);
    top = snapWithin(top, layout.cell, spanY);
  }
  return { left, top, width, height };
}

const clamp01 = (value: number) => Math.min(1, Math.max(0, value));

export function toPosition(rect: Rect, viewport: Viewport): Pick<ClockWidget, "x" | "y"> {
  const spanX = viewport.w - rect.width;
  const spanY = viewport.h - rect.height;
  return { x: spanX > 0 ? clamp01(rect.left / spanX) : 0.5, y: spanY > 0 ? clamp01(rect.top / spanY) : 0.5 };
}

/** Rough area of the logo, search bar and bookmarks — new widgets avoid it. */
export function mainColumnRect(viewport: Viewport, style: SearchStyle): Rect {
  const width = Math.min(style.width, viewport.w - 48) + 48;
  return { left: (viewport.w - width) / 2, top: (viewport.h * style.offsetTop) / 100 - 16, width, height: 460 };
}

const intersects = (a: Rect, b: Rect) =>
  a.left < b.left + b.width && b.left < a.left + a.width && a.top < b.top + b.height && b.top < a.top + a.height;

function findFreeSpot(width: number, height: number, taken: Rect[], viewport: Viewport, step: number) {
  const start = Math.ceil(EDGE / step) * step;
  for (let top = start; top + height <= viewport.h - EDGE / 2; top += step) {
    for (let left = start; left + width <= viewport.w - EDGE / 2; left += step) {
      const padded = { left: left - 12, top: top - 12, width: width + 24, height: height + 24 };
      if (!taken.some((rect) => intersects(padded, rect))) return { left, top };
    }
  }
  return null;
}

export function createWidget(face: ClockFaceId, id: string, settings: Settings, viewport: Viewport): ClockWidget {
  const base: ClockWidget = { ...DEFAULT_WIDGET, ...FACE_META[face].defaults, id, face };
  base.size = Math.max(SIZE_MIN, Math.min(base.size, Math.round(Math.min(viewport.w, viewport.h) * 0.32)));
  const { width, height } = widgetSize(base);
  const layout = settings.homeLayout;
  const taken = [
    ...settings.widgets.map((widget) => widgetRect(widget, viewport, layout)),
    mainColumnRect(viewport, settings.searchStyle),
    { left: viewport.w - 160, top: 0, width: 160, height: 84 }, // settings / edit buttons
  ];
  const count = settings.widgets.length;
  const spot = findFreeSpot(width, height, taken, viewport, layout.mode === "grid" ? layout.cell : 16) ?? {
    left: EDGE + (count % 8) * 28,
    top: EDGE + (count % 8) * 28,
  };
  return { ...base, ...toPosition({ left: spot.left, top: spot.top, width, height }, viewport) };
}

export function duplicateOf(source: ClockWidget, id: string, settings: Settings, viewport: Viewport): ClockWidget {
  const rect = widgetRect(source, viewport, settings.homeLayout);
  const shift = settings.homeLayout.mode === "grid" ? settings.homeLayout.cell : 24;
  const left = rect.left + shift + rect.width <= viewport.w ? rect.left + shift : Math.max(0, rect.left - shift);
  const top = rect.top + shift + rect.height <= viewport.h ? rect.top + shift : Math.max(0, rect.top - shift);
  return { ...source, id, ...toPosition({ ...rect, left, top }, viewport) };
}

/** Widget mutations shared by the home-screen editor and the settings section. */
export function useWidgetActions(setSettings: Dispatch<SetStateAction<Settings>>) {
  return useMemo(
    () => ({
      change: (id: string, patch: Partial<ClockWidget>) =>
        setSettings((s) => ({ ...s, widgets: s.widgets.map((widget) => (widget.id === id ? { ...widget, ...patch } : widget)) })),
      remove: (id: string) => setSettings((s) => ({ ...s, widgets: s.widgets.filter((widget) => widget.id !== id) })),
      /** Returns the id of the new widget. */
      add: (face: ClockFaceId) => {
        const id = uid();
        const viewport = readViewport();
        setSettings((s) => (s.widgets.length >= MAX_WIDGETS ? s : { ...s, widgets: [...s.widgets, createWidget(face, id, s, viewport)] }));
        return id;
      },
      duplicate: (sourceId: string) => {
        const id = uid();
        const viewport = readViewport();
        setSettings((s) => {
          const source = s.widgets.find((widget) => widget.id === sourceId);
          if (!source || s.widgets.length >= MAX_WIDGETS) return s;
          return { ...s, widgets: [...s.widgets, duplicateOf(source, id, s, viewport)] };
        });
        return id;
      },
      layout: (patch: Partial<HomeLayout>) => setSettings((s) => ({ ...s, homeLayout: { ...s.homeLayout, ...patch } })),
    }),
    [setSettings],
  );
}

export type WidgetActions = ReturnType<typeof useWidgetActions>;
